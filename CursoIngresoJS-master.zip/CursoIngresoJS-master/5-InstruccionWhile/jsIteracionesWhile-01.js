/*
al presionar el botón mostrar 10 repeticiones 
con números ASCENDENTE, desde el 1 al 10.*/
function mostrar()
{
	alert('iteración while');
}//FIN DE LA FUNCIÓN