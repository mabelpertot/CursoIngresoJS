/*
al presionar el botón mostrar 10 repeticiones 
con números DESCENDENTES, desde el 10 al 1.*/
function mostrar()
{
	var contador;
	contador=0; 
	alert('iteración while');

}//FIN DE LA FUNCIÓN