
function mostrar()
{
	alert("uno");
}
