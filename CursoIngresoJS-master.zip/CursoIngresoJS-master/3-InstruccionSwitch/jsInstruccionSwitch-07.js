function mostrar()
{
	var destinoIngresado =txtIdDestino.value;
	alert(destinoIngresado);

}//FIN DE LA FUNCIÓN