function mostrar()
{
	alert("ok");
}