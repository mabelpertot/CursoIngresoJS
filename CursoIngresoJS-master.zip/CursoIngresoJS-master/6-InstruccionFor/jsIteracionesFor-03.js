function mostrar()
{

	var repetciones = prompt("ingrese el número de repeticiones");
	alert("ok");


}//FIN DE LA FUNCIÓN