function mostrar()
{


	alert("ok");

}//FIN DE LA FUNCIÓN