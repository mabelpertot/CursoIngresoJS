function mostrar()
{

	alert("ok");
}