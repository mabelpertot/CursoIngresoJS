---
name: 'Reportar un error '
about: Crear un informe para la mejora continua
title: ''
labels: ''
assignees: ''

---

**Describa el error**
lo mas claro posibe y 

**Como ocurre el error**
Paso a paso , como sucede el error
1. Ir a '...'
2. Abrir '....'
3. algo hago'....'
4. ocurre el error

**Que se esperaba **
que deberia hacer y no esta haciendo

**Screenshots**
captura de pantalla con el error


**observaciones**
Todo dato que quiera agregar para mejorar la descripción
