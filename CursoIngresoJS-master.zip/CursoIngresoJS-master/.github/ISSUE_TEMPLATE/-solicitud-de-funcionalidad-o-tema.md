---
name: " Solicitud de funcionalidad o tema"
about: todas las sugerencias sobre los temas aboradados
title: ''
labels: ''
assignees: ''

---

**Describa el tema que desea**


**Describa como le gustaria que sea abordado**
A clear and concise description of what you want to happen.
